export async function onRequestPost({ request, env }) {
  try {
    if (!env.GEMINI_API_KEY) {
      return Response.json(
        { error: "AI চালু করতে Cloudflare Pages-এর Settings > Variables and Secrets-এ GEMINI_API_KEY যোগ করুন।" },
        { status: 503 }
      );
    }

    const body = await request.json();
    const messages = Array.isArray(body.messages) ? body.messages : [];
    const contents = messages
      .filter(m => ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-20)
      .map(m => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content.slice(0, 12000) }]
      }));

    if (!contents.length || contents.at(-1).role !== "user") {
      return Response.json({ error: "একটি user message পাঠান।" }, { status: 400 });
    }

    const model = env.GEMINI_MODEL || "gemini-2.5-flash";
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": env.GEMINI_API_KEY
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: "You are Carain, a friendly, helpful personal AI assistant. Reply in the user's language. Be clear, honest, and warm. Do not claim to have abilities you do not have." }]
          },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
        })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      return Response.json(
        { error: data?.error?.message || "Gemini API অনুরোধ ব্যর্থ হয়েছে। API key ও free-tier quota পরীক্ষা করুন।" },
        { status: response.status }
      );
    }

    const reply = data?.candidates?.[0]?.content?.parts
      ?.map(p => p.text || "")
      .join("")
      .trim();

    return Response.json({ reply: reply || "দুঃখিত, এবার উত্তর তৈরি করা যায়নি।" });
  } catch (error) {
    return Response.json({ error: "সার্ভার অনুরোধে সমস্যা হয়েছে। আবার চেষ্টা করুন।" }, { status: 500 });
  }
}
