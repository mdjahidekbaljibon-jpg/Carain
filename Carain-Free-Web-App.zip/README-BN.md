# Carain — ফ্রি Personal AI Web App

এটি Cloudflare Pages-এর জন্য তৈরি একটি installable PWA starter। Android Chrome থেকে HTTPS ওয়েবসাইট খুলে **Install app / Add to Home screen** করা যাবে।

## খরচ
- Cloudflare Pages-এর Free plan দিয়ে শুরু করা যায়; free plan-এর সীমা ও শর্ত পরিবর্তন হতে পারে।
- Google Gemini API-তে নির্বাচিত কিছু মডেলের Free Tier আছে; ব্যবহারসীমা/মডেল-প্রাপ্যতা অ্যাকাউন্টভেদে বদলাতে পারে।
- কোনো পেইড প্ল্যানে আপগ্রেড করবে না। API-তে billing enable করবে না।
- Free quota শেষ হলে উত্তর বন্ধ/সীমিত হতে পারে; নিজে থেকে পেইড হবে না যদি paid billing চালু না করো।

## একবারের সেটআপ
1. ZIP Extract করো।
2. Cloudflare account তৈরি/লগইন করে **Workers & Pages > Create > Pages > Connect to Git** বেছে নাও।
3. এই project-টি GitHub repository-তে upload করে Cloudflare Pages-এ সেটি connect করো।
4. Build settings:
   - Framework preset: `None`
   - Build command: ফাঁকা রাখো
   - Build output directory: `public`
5. Deploy হলে একটি `*.pages.dev` ঠিকানা পাবে।
6. Google AI Studio-তে গিয়ে Free Tier project-এর API key তৈরি করো: https://aistudio.google.com/app/apikey
7. Cloudflare Pages project > Settings > Variables and Secrets > Add variable:
   - Name: `GEMINI_API_KEY`
   - Value: তোমার API key
   - Secret হিসেবে রাখবে; কখনো public code বা কাউকে পাঠাবে না।
8. চাইলে `GEMINI_MODEL` নামে variable যোগ করতে পারো; default `gemini-2.5-flash`। তোমার Free Tier-এ যে model available সেটি ব্যবহার করবে।
9. নতুন deployment/redeploy করো।

## ব্যবহার
- নিজের `*.pages.dev` ওয়েব ঠিকানা Android Chrome-এ খোলো।
- Browser menu থেকে Install app / Add to Home screen চাপো।
- Chat history বর্তমানে ওই browser/device-এর localStorage-এ থাকে; অন্য ডিভাইসে sync হয় না।

## গুরুত্বপূর্ণ
- ZIP-এ কোনো API key নেই।
- AI চালাতে নিজের Gemini API key যোগ করতে হবে।
- Free Tier quota, model availability, regional access ও terms Google পরিবর্তন করতে পারে। AI Studio-তে Free Tier নিশ্চিত করো এবং billing enable করো না।
- Free hosting এবং API-র limits থাকতে পারে; unlimited service নয়।
- এটি Carain-এর starter app, ChatGPT/GPT-6-এর হুবহু কপি নয়।
